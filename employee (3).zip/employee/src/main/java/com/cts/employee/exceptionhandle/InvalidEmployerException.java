package com.cts.employee.exceptionhandle;

public class InvalidEmployerException extends RuntimeException {
	private static  final long serialVersionUID=1L;
	private String empName;
	
	public InvalidEmployerException(String empName) {
		System.out.println(empName);
		this.empName=empName;
	}
	@Override
	public String toString() {
		return empName+" is not an Employee,He is the owner of the company";
	}
}
