package com.cts.employee.service;

import org.springframework.stereotype.Service;

import com.cts.employee.exceptionhandle.InvalidEmployerException;
import com.cts.employee.model.Emp;

@Service
public class LoginService {
	public boolean validate(Emp emp) {

		String empName=emp.getEmpName();
		if(!"CEO".equals(empName))
		
			return true;
		else
			throw new InvalidEmployerException(empName);
		}


}
