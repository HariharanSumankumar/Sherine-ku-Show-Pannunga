package com.cts.employee.globalexceptionhandle;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.cts.employee.exceptionhandle.InvalidEmployerException;

@ControllerAdvice
public class GlobalExceptionHandler {

	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(InvalidEmployerException.class)
	public ModelAndView handleInvalidEmployerException(Exception exception) {
		ModelAndView modelAndView=new ModelAndView();
		System.out.println("handleexception");
		modelAndView.addObject("exception",exception);
		modelAndView.setViewName("error");
		return modelAndView;
		
	}
	
}
